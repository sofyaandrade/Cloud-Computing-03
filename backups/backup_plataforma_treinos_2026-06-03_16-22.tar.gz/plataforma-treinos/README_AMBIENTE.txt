Plataforma de Treinos e Exercícios Online
Diretórios simulam VPC, sub-redes, storage, bancos e VMs do tema.
